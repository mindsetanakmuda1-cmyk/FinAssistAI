# FinAssist AI — Android project

This is a native Android Studio project (Java, no third-party app libraries).

## Included
- Modern green finance dashboard
- Total balance, income, and expense summaries
- Add income and expense transactions
- Category selector and transaction history
- Local persistent storage using Android SharedPreferences (JSON)

## Build APK
1. Install Android Studio on a computer.
2. Open this `FinAssistAI` folder in Android Studio.
3. Let Gradle sync finish (requires internet for Android Gradle Plugin).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.finassist.ai`
Minimum Android: 6.0 (API 23)

Note: This ZIP contains the full project source, not a precompiled APK. It needs Android Studio/Gradle to compile.
