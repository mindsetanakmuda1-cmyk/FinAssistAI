package com.finassist.ai;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.NumberFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(244,247,246), GREEN=Color.rgb(16,145,105), DARK=Color.rgb(25,40,40);
    private LinearLayout root, list;
    private TextView balanceText, incomeText, expenseText, emptyText;
    private JSONArray transactions;
    private android.content.SharedPreferences prefs;
    private long balance=0, income=0, expense=0;
    private NumberFormat rupiah=NumberFormat.getCurrencyInstance(new Locale("id","ID"));

    private static int forty(){ return 40; }
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(Color.WHITE);
        prefs=getSharedPreferences("finassist_data",MODE_PRIVATE);
        loadData(); buildUI();
    }
    private void loadData(){
        try { transactions=new JSONArray(prefs.getString("transactions","[]")); } catch(Exception e){ transactions=new JSONArray(); }
        recalc();
    }
    private void saveData(){ prefs.edit().putString("transactions",transactions.toString()).apply(); }
    private void recalc(){
        balance=0; income=0; expense=0;
        for(int i=0;i<transactions.length();i++){
            JSONObject o=transactions.optJSONObject(i); if(o==null) continue;
            long amount=o.optLong("amount",0);
            if("Masuk".equals(o.optString("type"))){ income+=amount; balance+=amount; }
            else { expense+=amount; balance-=amount; }
        }
    }
    private String money(long n){ return "Rp"+rupiah.format(n).replace("Rp","").replace(",00","").trim(); }
    private GradientDrawable shape(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    private LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v,int a){ v.setPadding(a,a,a,a); }
    private void buildUI(){
        root=column(); root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(root);
        setContentView(scroll);
        LinearLayout header=row(); header.setPadding(22,22,22,12);
        LinearLayout title=column(); title.addView(text("FinAssist",25,Color.rgb(24,45,40),true)); title.addView(text("Keuangan lebih teratur.",13,Color.GRAY,false));
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView badge=text("●  AKTIF",11,GREEN,true); header.addView(badge); root.addView(header);

        LinearLayout card=column(); card.setPadding(22,22,22,22);
        GradientDrawable gd=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(13,150,109),Color.rgb(8,103,83)}); gd.setCornerRadius(28); card.setBackground(gd);
        card.addView(text("TOTAL SALDO",12,Color.rgb(220,245,236),true));
        balanceText=text(money(balance),32,Color.WHITE,true); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=8; card.addView(balanceText,bp);
        card.addView(text("Ringkasan keuangan kamu",12,Color.rgb(220,245,236),false));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(18,12,18,16); root.addView(card,cp);

        LinearLayout stats=row(); stats.setPadding(18,0,18,0);
        LinearLayout inc=statCard("PEMASUKAN",GREEN); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-2,1); sp.rightMargin=7; stats.addView(inc,sp);
        LinearLayout exp=statCard("PENGELUARAN",Color.rgb(221,112,85)); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,-2,1); ep.leftMargin=7; stats.addView(exp,ep); root.addView(stats);
        incomeText=(TextView)inc.getChildAt(1); expenseText=(TextView)exp.getChildAt(1);

        LinearLayout actions=row(); actions.setPadding(18,18,18,8);
        Button addIn=button("+ Pemasukan"); addIn.setOnClickListener(v->showTransaction("Masuk"));
        Button addOut=button("− Pengeluaran"); addOut.setOnClickListener(v->showTransaction("Keluar"));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,54,1); ap.rightMargin=6; actions.addView(addIn,ap);
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(0,54,1); op.leftMargin=6; actions.addView(addOut,op); root.addView(actions);

        LinearLayout section=row(); section.setPadding(22,18,22,10);
        section.addView(text("Transaksi terbaru",18,Color.rgb(24,45,40),true),new LinearLayout.LayoutParams(0,-2,1));
        section.addView(text("Semua aktivitas",12,GREEN,true)); root.addView(section);
        list=column(); list.setPadding(18,0,18,24); root.addView(list);
        refresh();
    }
    private LinearLayout statCard(String label,int accent){
        LinearLayout c=column(); c.setPadding(15,15,12,15); c.setBackground(shape(Color.WHITE,20));
        c.addView(text(label,10,Color.GRAY,true)); TextView value=text("Rp0",17,accent,true);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=8; c.addView(value,p); return c;
    }
    private Button button(String label){
        Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(13);
        b.setAllCaps(false); b.setBackground(shape(GREEN,16)); return b;
    }
    private void refresh(){
        recalc(); balanceText.setText(money(balance)); incomeText.setText(money(income)); expenseText.setText(money(expense));
        list.removeAllViews();
        if(transactions.length()==0){ TextView e=text("Belum ada transaksi.\nCatat pemasukan atau pengeluaran pertamamu.",13,Color.GRAY,false); e.setGravity(Gravity.CENTER); e.setPadding(15,28,15,28); e.setBackground(shape(Color.WHITE,18)); list.addView(e); return; }
        for(int i=transactions.length()-1;i>=0;i--){
            JSONObject o=transactions.optJSONObject(i); if(o==null)continue;
            boolean masuk="Masuk".equals(o.optString("type"));
            LinearLayout item=row(); item.setPadding(15,14,15,14); item.setBackground(shape(Color.WHITE,18));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=8; list.addView(item,p);
            TextView icon=text(masuk?"+":"−",22,masuk?GREEN:Color.rgb(221,112,85),true); icon.setGravity(Gravity.CENTER); icon.setBackground(shape(BG,14));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(44,44); ip.rightMargin=12; item.addView(icon,ip);
            LinearLayout desc=column(); desc.addView(text(o.optString("note","Transaksi"),14,Color.rgb(35,48,45),true)); desc.addView(text(o.optString("date",""),11,Color.GRAY,false));
            item.addView(desc,new LinearLayout.LayoutParams(0,-2,1));
            item.addView(text((masuk?"+ ":"− ")+money(o.optLong("amount")),13,masuk?GREEN:Color.rgb(221,112,85),true));
        }
    }
    private void showTransaction(String type){
        LinearLayout box=column(); box.setPadding(8,4,8,0);
        EditText amount=new EditText(this); amount.setHint("Nominal (contoh: 15000)"); amount.setInputType(2); box.addView(amount);
        EditText note=new EditText(this); note.setHint("Keterangan"); box.addView(note);
        String[] cats={"Makan & minum","Transportasi","Tabungan","Belanja","Hiburan","Gaji / uang saku","Lainnya"};
        Spinner spinner=new Spinner(this); spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cats)); box.addView(spinner);
        new AlertDialog.Builder(this).setTitle(type.equals("Masuk")?"Tambah pemasukan":"Tambah pengeluaran").setView(box)
            .setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
                String raw=amount.getText().toString().trim();
                try{
                    long n=Long.parseLong(raw); if(n<=0)throw new Exception();
                    JSONObject o=new JSONObject(); o.put("type",type); o.put("amount",n);
                    o.put("note",note.getText().toString().trim().isEmpty()?spinner.getSelectedItem().toString():note.getText().toString().trim());
                    o.put("category",spinner.getSelectedItem().toString());
                    o.put("date",new java.text.SimpleDateFormat("dd MMM yyyy, HH:mm",new Locale("id","ID")).format(new Date()));
                    transactions.put(o); saveData(); refresh();
                    Toast.makeText(this,"Transaksi tersimpan",Toast.LENGTH_SHORT).show();
                }catch(Exception ex){ Toast.makeText(this,"Masukkan nominal yang valid",Toast.LENGTH_SHORT).show(); }
            }).show();
    }
}